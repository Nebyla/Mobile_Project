part of '../ui.dart';

class BasicInfoCompanyCard extends StatelessWidget {
  final String? text;
  final Color? color;

  const BasicInfoCompanyCard({super.key, this.text, this.color = Colors.white,});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.all(15.0),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget(text: "Основная информация", color: Colors.black, fontSize: 22, fontWeight: FontWeight.w500,),
                SizedBox(height: 20,),
                const Text(
                  'Имя',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Form(
                  child: NameCompanyInputs(
                      onChanged: (value) {
                        context.read<CompanyBloc>().add(SurnameChanged(value));
                      },
                      labelText: "Фамилия",
                      hintText: "Иванов"),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'Наименование',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Form(
                  child: NameCompanyInputs(
                      onChanged: (value) {
                        context
                            .read<CompanyBloc>()
                            .add(NameCompanyChanged(value));
                      },
                      labelText: "Введите наименование",
                      hintText: "Xsalesmen"),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'БИК',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Form(
                  child: BicInputs(
                    onChanged: (value) {
                      context.read<CompanyBloc>().add(BicChanged(value));
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'Расчётный счет',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Form(
                  child: EstimatedInputs(
                    onChanged: (value) {
                      context.read<CompanyBloc>().add(EstimatedChanged(value));
                    },
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'Корреспондентский счет',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 5),
                Form(
                  child: CorresCheckInputs(
                    onChanged: (value) {
                      context
                          .read<CompanyBloc>()
                          .add(CorrespondentChanged(value));
                    },
                  ),
                ),
                SizedBox(height: 15,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SecondaryButton(text: "Сохранить изменения", onPressed: (){}
                      ),
                    PrimaryButton(
                      text: "Отмена",
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ],
            ),

          ),

        ));
  }
}
