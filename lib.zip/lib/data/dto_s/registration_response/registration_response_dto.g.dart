// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'registration_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_RegistrationResponseDTO _$$_RegistrationResponseDTOFromJson(
        Map<String, dynamic> json) =>
    _$_RegistrationResponseDTO(
      message: json['message'] as String,
    );

Map<String, dynamic> _$$_RegistrationResponseDTOToJson(
        _$_RegistrationResponseDTO instance) =>
    <String, dynamic>{
      'message': instance.message,
    };
