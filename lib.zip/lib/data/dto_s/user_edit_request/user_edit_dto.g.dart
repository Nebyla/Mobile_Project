// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_edit_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UserEditRequestDTO _$$_UserEditRequestDTOFromJson(
        Map<String, dynamic> json) =>
    _$_UserEditRequestDTO(
      firstName: json['firstName'] as String,
      lastName: json['lastName'] as String,
      middleName: json['middleName'] as String,
    );

Map<String, dynamic> _$$_UserEditRequestDTOToJson(
        _$_UserEditRequestDTO instance) =>
    <String, dynamic>{
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'middleName': instance.middleName,
    };
