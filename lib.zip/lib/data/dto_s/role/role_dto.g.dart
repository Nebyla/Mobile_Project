// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'role_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_RoleDTO _$$_RoleDTOFromJson(Map<String, dynamic> json) => _$_RoleDTO(
      id: json['id'] as int,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$$_RoleDTOToJson(_$_RoleDTO instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
