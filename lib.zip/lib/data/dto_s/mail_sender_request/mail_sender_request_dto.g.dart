// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mail_sender_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MailSenderRequestDTO _$$_MailSenderRequestDTOFromJson(
        Map<String, dynamic> json) =>
    _$_MailSenderRequestDTO(
      email: json['email'] as String,
      password: json['password'] as String,
    );

Map<String, dynamic> _$$_MailSenderRequestDTOToJson(
        _$_MailSenderRequestDTO instance) =>
    <String, dynamic>{
      'email': instance.email,
      'password': instance.password,
    };
