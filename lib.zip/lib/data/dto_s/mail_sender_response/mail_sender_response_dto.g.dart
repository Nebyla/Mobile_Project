// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mail_sender_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MailSenderResponseDTO _$$_MailSenderResponseDTOFromJson(
        Map<String, dynamic> json) =>
    _$_MailSenderResponseDTO(
      message: json['message'] as String,
    );

Map<String, dynamic> _$$_MailSenderResponseDTOToJson(
        _$_MailSenderResponseDTO instance) =>
    <String, dynamic>{
      'message': instance.message,
    };
